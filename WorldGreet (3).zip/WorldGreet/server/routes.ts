import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Translation proxy endpoint supporting multiple services
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, source, target, service = "google" } = req.body;
      
      if (!text || !target) {
        return res.status(400).json({ error: "Missing required fields: text, target" });
      }

      if (service === "google") {
        // Google Translate API integration
        const apiKey = process.env.GOOGLE_TRANSLATE_API_KEY;
        
        if (!apiKey) {
          return res.status(500).json({ 
            error: "Google Translate API key not configured",
            message: "Please add GOOGLE_TRANSLATE_API_KEY to environment variables"
          });
        }

        const googleResponse = await fetch(
          `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              q: text,
              source: source === "auto" ? undefined : source,
              target: target,
              format: "text"
            })
          }
        );

        if (!googleResponse.ok) {
          throw new Error(`Google Translate API error: ${googleResponse.status}`);
        }

        const googleData = await googleResponse.json();
        const translation = googleData.data.translations[0];
        
        res.json({
          translatedText: translation.translatedText,
          detectedLanguage: translation.detectedSourceLanguage,
          service: "google"
        });

      } else {
        // LibreTranslate fallback
        const response = await fetch("https://libretranslate.com/translate", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            q: text,
            source: source || "auto",
            target: target,
            format: "text"
          })
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error(`LibreTranslate API error ${response.status}:`, errorText);
          throw new Error(`LibreTranslate API error: ${response.status}`);
        }

        const data = await response.json();
        res.json({
          translatedText: data.translatedText,
          detectedLanguage: data.detectedLanguage,
          service: "libretranslate"
        });
      }

    } catch (error) {
      console.error("Translation proxy error:", error);
      res.status(500).json({ 
        error: "Translation service unavailable",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
