import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeftRight, Languages, Globe, Edit, X, Loader2 } from "lucide-react";
import type { Language } from "@shared/schema";
import { cn } from "@/lib/utils";

const languages: { value: Language; label: string; flag: string }[] = [
  { value: "english", label: "English", flag: "🇺🇸" },
  { value: "swahili", label: "Swahili", flag: "🇰🇪" },
  { value: "mandarin", label: "Mandarin", flag: "🇨🇳" },
  { value: "hindi", label: "Hindi", flag: "🇮🇳" },
  { value: "arabic", label: "Arabic", flag: "🇸🇦" },
  { value: "spanish", label: "Spanish", flag: "🇪🇸" },
  { value: "russian", label: "Russian", flag: "🇷🇺" },
  { value: "french", label: "French", flag: "🇫🇷" },
  { value: "portuguese", label: "Portuguese", flag: "🇧🇷" },
  { value: "japanese", label: "Japanese", flag: "🇯🇵" },
];

const quickSuggestions = ["hello", "thank you", "good morning", "goodbye", "please", "yes", "no", "help", "water", "food"];

interface TranslatorCardProps {
  fromLanguage: Language;
  toLanguage: Language;
  inputText: string;
  isLoading: boolean;
  onFromLanguageChange: (language: Language) => void;
  onToLanguageChange: (language: Language) => void;
  onInputChange: (text: string) => void;
  onTranslate: () => void;
  onSwapLanguages: () => void;
}

export function TranslatorCard({
  fromLanguage,
  toLanguage,
  inputText,
  isLoading,
  onFromLanguageChange,
  onToLanguageChange,
  onInputChange,
  onTranslate,
  onSwapLanguages,
}: TranslatorCardProps) {
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onTranslate();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    onInputChange(suggestion);
  };

  const clearInput = () => {
    onInputChange('');
  };

  return (
    <Card className="overflow-hidden shadow-lg border-slate-200">
      {/* Language Selection Section */}
      <div className="bg-gradient-to-r from-primary to-secondary p-6 text-white">
        <div className="grid md:grid-cols-2 gap-6">
          {/* From Language */}
          <div className="space-y-2">
            <Label className="block text-sm font-medium text-white/90">
              <Languages className="inline mr-2 h-4 w-4" />
              From Language
            </Label>
            <Select value={fromLanguage} onValueChange={onFromLanguageChange}>
              <SelectTrigger className="w-full px-4 py-3 rounded-xl border-2 border-white/20 bg-white/10 text-white placeholder:text-white/70 focus:border-white focus:ring-2 focus:ring-white/20 backdrop-blur-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value} className="text-slate-900">
                    {lang.flag} {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Swap Button - Desktop */}
          <div className="hidden md:flex items-end justify-center pb-3">
            <Button
              onClick={onSwapLanguages}
              className="p-3 rounded-full bg-white/20 hover:bg-white/30 transition-all duration-200 transform hover:scale-110 border-0"
              size="icon"
            >
              <ArrowLeftRight className="h-5 w-5 text-white" />
            </Button>
          </div>

          {/* To Language */}
          <div className={cn("space-y-2", "md:col-start-2")}>
            <Label className="block text-sm font-medium text-white/90">
              <Globe className="inline mr-2 h-4 w-4" />
              To Language
            </Label>
            <Select value={toLanguage} onValueChange={onToLanguageChange}>
              <SelectTrigger className="w-full px-4 py-3 rounded-xl border-2 border-white/20 bg-white/10 text-white placeholder:text-white/70 focus:border-white focus:ring-2 focus:ring-white/20 backdrop-blur-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value} className="text-slate-900">
                    {lang.flag} {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Mobile Swap Button */}
          <div className="md:hidden flex justify-center">
            <Button
              onClick={onSwapLanguages}
              className="p-3 rounded-full bg-white/20 hover:bg-white/30 transition-all duration-200 transform hover:scale-110 border-0"
              size="icon"
            >
              <ArrowLeftRight className="h-5 w-5 text-white" />
            </Button>
          </div>
        </div>
      </div>

      {/* Input Section */}
      <CardContent className="p-6 space-y-6">
        {/* Quick Suggestions */}
        <div className="space-y-3">
          <Label className="block text-sm font-medium text-slate-700">
            <span className="text-accent-500 mr-2">💡</span>
            Quick Suggestions
          </Label>
          <div className="flex flex-wrap gap-2">
            {quickSuggestions.map((suggestion) => (
              <Button
                key={suggestion}
                onClick={() => handleSuggestionClick(suggestion)}
                variant="outline"
                size="sm"
                className="px-4 py-2 bg-slate-100 hover:bg-primary-50 hover:text-primary-600 text-slate-700 rounded-full text-sm font-medium transition-all duration-200 border-slate-200 hover:border-primary-200"
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>

        {/* Text Input */}
        <div className="space-y-3">
          <Label htmlFor="inputText" className="block text-sm font-medium text-slate-700">
            <Edit className="inline mr-2 h-4 w-4" />
            Enter word or phrase
          </Label>
          <div className="relative">
            <Input
              id="inputText"
              type="text"
              value={inputText}
              onChange={(e) => onInputChange(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a word like 'hello', 'thank you', or 'good morning'..."
              className="w-full px-4 py-4 pr-12 text-lg border-2 border-slate-200 rounded-xl focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-200"
            />
            {inputText && (
              <Button
                onClick={clearInput}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 text-slate-400 hover:text-slate-600 transition-colors duration-200 border-0 bg-transparent hover:bg-transparent"
                size="icon"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Translate Button */}
        <Button
          onClick={onTranslate}
          disabled={isLoading || !inputText.trim()}
          className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-200 transform hover:scale-[1.02] hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-primary/20 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Translating...
            </>
          ) : (
            <>
              <Languages className="mr-2 h-4 w-4" />
              Translate
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
