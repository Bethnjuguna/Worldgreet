import type { Language, TranslationData, TranslationResult } from "@shared/schema";

type DictionaryEntry = {
  [key in Language]: TranslationData;
}

const dictionary: Record<string, DictionaryEntry> = {
  hello: {
    english: { text: "Hello", pronunciation: "/həˈloʊ/" },
    swahili: { text: "Jambo", pronunciation: "/ˈdʒæmboʊ/" },
    mandarin: { text: "你好", pronunciation: "Nǐ hǎo" },
    hindi: { text: "नमस्ते", pronunciation: "Namaste" },
    arabic: { text: "مرحبا", pronunciation: "Marhaba" },
    spanish: { text: "Hola", pronunciation: "/ˈola/" },
    russian: { text: "Привет", pronunciation: "Privet" },
    french: { text: "Bonjour", pronunciation: "/bonˈʒuʁ/" },
    portuguese: { text: "Olá", pronunciation: "/oˈla/" },
    japanese: { text: "こんにちは", pronunciation: "Konnichiwa" }
  },
  "thank you": {
    english: { text: "Thank you", pronunciation: "/θæŋk juː/" },
    swahili: { text: "Asante", pronunciation: "/aˈsante/" },
    mandarin: { text: "谢谢", pronunciation: "Xièxiè" },
    hindi: { text: "धन्यवाद", pronunciation: "Dhanyavaad" },
    arabic: { text: "شكرا", pronunciation: "Shukran" },
    spanish: { text: "Gracias", pronunciation: "/ˈɡɾa.θjas/" },
    russian: { text: "Спасибо", pronunciation: "Spasibo" },
    french: { text: "Merci", pronunciation: "/mɛʁ.si/" },
    portuguese: { text: "Obrigado", pronunciation: "/obɾiˈɡadu/" },
    japanese: { text: "ありがとう", pronunciation: "Arigatou" }
  },
  "good morning": {
    english: { text: "Good morning", pronunciation: "/ɡʊd ˈmɔːrnɪŋ/" },
    swahili: { text: "Habari za asubuhi", pronunciation: "/haˈbari za asuˈbuhi/" },
    mandarin: { text: "早上好", pronunciation: "Zǎoshang hǎo" },
    hindi: { text: "सुप्रभात", pronunciation: "Suprabhat" },
    arabic: { text: "صباح الخير", pronunciation: "Sabah al-khayr" },
    spanish: { text: "Buenos días", pronunciation: "/ˈbwe.nos ˈdi.as/" },
    russian: { text: "Доброе утро", pronunciation: "Dobroye utro" },
    french: { text: "Bonjour", pronunciation: "/bonˈʒuʁ/" },
    portuguese: { text: "Bom dia", pronunciation: "/bõ ˈdʒi.ɐ/" },
    japanese: { text: "おはよう", pronunciation: "Ohayou" }
  },
  goodbye: {
    english: { text: "Goodbye", pronunciation: "/ɡʊdˈbaɪ/" },
    swahili: { text: "Kwa heri", pronunciation: "/kwa ˈheri/" },
    mandarin: { text: "再见", pronunciation: "Zàijiàn" },
    hindi: { text: "अलविदा", pronunciation: "Alvida" },
    arabic: { text: "وداعا", pronunciation: "Wada'an" },
    spanish: { text: "Adiós", pronunciation: "/aˈðjos/" },
    russian: { text: "До свидания", pronunciation: "Do svidaniya" },
    french: { text: "Au revoir", pronunciation: "/o ʁə.vwaʁ/" },
    portuguese: { text: "Tchau", pronunciation: "/ˈtʃaw/" },
    japanese: { text: "さようなら", pronunciation: "Sayounara" }
  },
  please: {
    english: { text: "Please", pronunciation: "/pliːz/" },
    swahili: { text: "Tafadhali", pronunciation: "/tafaˈdhali/" },
    mandarin: { text: "请", pronunciation: "Qǐng" },
    hindi: { text: "कृपया", pronunciation: "Kripaya" },
    arabic: { text: "من فضلك", pronunciation: "Min fadlik" },
    spanish: { text: "Por favor", pronunciation: "/poɾ faˈβoɾ/" },
    russian: { text: "Пожалуйста", pronunciation: "Pozhaluysta" },
    french: { text: "S'il vous plaît", pronunciation: "/sil vu plɛ/" },
    portuguese: { text: "Por favor", pronunciation: "/poʁ faˈvoʁ/" },
    japanese: { text: "お願いします", pronunciation: "Onegaishimasu" }
  },
  "excuse me": {
    english: { text: "Excuse me", pronunciation: "/ɪkˈskjuːz miː/" },
    swahili: { text: "Samahani", pronunciation: "/samaˈhani/" },
    mandarin: { text: "不好意思", pronunciation: "Bù hǎoyìsi" },
    hindi: { text: "माफ़ करिए", pronunciation: "Maaf kariye" },
    arabic: { text: "عفواً", pronunciation: "Afwan" },
    spanish: { text: "Disculpe", pronunciation: "/disˈkulpe/" },
    russian: { text: "Извините", pronunciation: "Izvinite" },
    french: { text: "Excusez-moi", pronunciation: "/ɛkskyzɛ mwa/" },
    portuguese: { text: "Com licença", pronunciation: "/kõ liˈsẽsɐ/" },
    japanese: { text: "すみません", pronunciation: "Sumimasen" }
  },
  "how are you": {
    english: { text: "How are you?", pronunciation: "/haʊ ɑːr juː/" },
    swahili: { text: "Habari yako?", pronunciation: "/haˈbari ˈjako/" },
    mandarin: { text: "你好吗？", pronunciation: "Nǐ hǎo ma?" },
    hindi: { text: "आप कैसे हैं?", pronunciation: "Aap kaise hain?" },
    arabic: { text: "كيف حالك؟", pronunciation: "Kayf halak?" },
    spanish: { text: "¿Cómo estás?", pronunciation: "/ˈkomo esˈtas/" },
    russian: { text: "Как дела?", pronunciation: "Kak dela?" },
    french: { text: "Comment allez-vous?", pronunciation: "/kɔmɑ̃ t‿ale vu/" },
    portuguese: { text: "Como você está?", pronunciation: "/ˈkomu voˈse esˈta/" },
    japanese: { text: "元気ですか？", pronunciation: "Genki desu ka?" }
  },
  "yes": {
    english: { text: "Yes", pronunciation: "/jɛs/" },
    swahili: { text: "Ndiyo", pronunciation: "/ˈndiyo/" },
    mandarin: { text: "是", pronunciation: "Shì" },
    hindi: { text: "हाँ", pronunciation: "Haan" },
    arabic: { text: "نعم", pronunciation: "Na'am" },
    spanish: { text: "Sí", pronunciation: "/si/" },
    russian: { text: "Да", pronunciation: "Da" },
    french: { text: "Oui", pronunciation: "/wi/" },
    portuguese: { text: "Sim", pronunciation: "/sĩ/" },
    japanese: { text: "はい", pronunciation: "Hai" }
  },
  "no": {
    english: { text: "No", pronunciation: "/noʊ/" },
    swahili: { text: "Hapana", pronunciation: "/haˈpana/" },
    mandarin: { text: "不", pronunciation: "Bù" },
    hindi: { text: "नहीं", pronunciation: "Nahin" },
    arabic: { text: "لا", pronunciation: "La" },
    spanish: { text: "No", pronunciation: "/no/" },
    russian: { text: "Нет", pronunciation: "Net" },
    french: { text: "Non", pronunciation: "/nɔ̃/" },
    portuguese: { text: "Não", pronunciation: "/nɐ̃w̃/" },
    japanese: { text: "いいえ", pronunciation: "Iie" }
  },
  "welcome": {
    english: { text: "Welcome", pronunciation: "/ˈwɛlkəm/" },
    swahili: { text: "Karibu", pronunciation: "/kaˈribu/" },
    mandarin: { text: "欢迎", pronunciation: "Huānyíng" },
    hindi: { text: "स्वागत", pronunciation: "Swagat" },
    arabic: { text: "أهلا وسهلا", pronunciation: "Ahlan wa sahlan" },
    spanish: { text: "Bienvenido", pronunciation: "/bjenbeˈnido/" },
    russian: { text: "Добро пожаловать", pronunciation: "Dobro pozhalovat'" },
    french: { text: "Bienvenue", pronunciation: "/bjɛ̃vəny/" },
    portuguese: { text: "Bem-vindo", pronunciation: "/bẽ ˈvĩdu/" },
    japanese: { text: "いらっしゃいませ", pronunciation: "Irasshaimase" }
  },
  "good night": {
    english: { text: "Good night", pronunciation: "/ɡʊd naɪt/" },
    swahili: { text: "Usiku mwema", pronunciation: "/uˈsiku ˈmwema/" },
    mandarin: { text: "晚安", pronunciation: "Wǎn'ān" },
    hindi: { text: "शुभ रात्रि", pronunciation: "Shubh ratri" },
    arabic: { text: "تصبح على خير", pronunciation: "Tusbih ala khayr" },
    spanish: { text: "Buenas noches", pronunciation: "/ˈbwenas ˈnotʃes/" },
    russian: { text: "Спокойной ночи", pronunciation: "Spokoinoi nochi" },
    french: { text: "Bonne nuit", pronunciation: "/bɔn nɥi/" },
    portuguese: { text: "Boa noite", pronunciation: "/ˈboa ˈnojtʃi/" },
    japanese: { text: "おやすみ", pronunciation: "Oyasumi" }
  },
  "sorry": {
    english: { text: "Sorry", pronunciation: "/ˈsɑri/" },
    swahili: { text: "Pole", pronunciation: "/ˈpole/" },
    mandarin: { text: "对不起", pronunciation: "Duìbuqǐ" },
    hindi: { text: "माफ़ करना", pronunciation: "Maaf karna" },
    arabic: { text: "آسف", pronunciation: "Aasif" },
    spanish: { text: "Lo siento", pronunciation: "/lo ˈsjento/" },
    russian: { text: "Извините", pronunciation: "Izvinite" },
    french: { text: "Désolé", pronunciation: "/dezɔle/" },
    portuguese: { text: "Desculpa", pronunciation: "/desˈkulpɐ/" },
    japanese: { text: "ごめん", pronunciation: "Gomen" }
  },
  "help": {
    english: { text: "Help", pronunciation: "/hɛlp/" },
    swahili: { text: "Msaada", pronunciation: "/mˈsaːda/" },
    mandarin: { text: "帮助", pronunciation: "Bāngzhù" },
    hindi: { text: "मदद", pronunciation: "Madad" },
    arabic: { text: "مساعدة", pronunciation: "Musa'ada" },
    spanish: { text: "Ayuda", pronunciation: "/aˈʝuda/" },
    russian: { text: "Помощь", pronunciation: "Pomoshch'" },
    french: { text: "Aide", pronunciation: "/ɛd/" },
    portuguese: { text: "Ajuda", pronunciation: "/aˈʒudɐ/" },
    japanese: { text: "助け", pronunciation: "Tasuke" }
  },
  "water": {
    english: { text: "Water", pronunciation: "/ˈwɔtər/" },
    swahili: { text: "Maji", pronunciation: "/ˈmadʒi/" },
    mandarin: { text: "水", pronunciation: "Shuǐ" },
    hindi: { text: "पानी", pronunciation: "Paani" },
    arabic: { text: "ماء", pronunciation: "Maa'" },
    spanish: { text: "Agua", pronunciation: "/ˈaɣwa/" },
    russian: { text: "Вода", pronunciation: "Voda" },
    french: { text: "Eau", pronunciation: "/o/" },
    portuguese: { text: "Água", pronunciation: "/ˈaɡwɐ/" },
    japanese: { text: "水", pronunciation: "Mizu" }
  },
  "food": {
    english: { text: "Food", pronunciation: "/fud/" },
    swahili: { text: "Chakula", pronunciation: "/tʃaˈkula/" },
    mandarin: { text: "食物", pronunciation: "Shíwù" },
    hindi: { text: "खाना", pronunciation: "Khaana" },
    arabic: { text: "طعام", pronunciation: "Ta'aam" },
    spanish: { text: "Comida", pronunciation: "/koˈmida/" },
    russian: { text: "Еда", pronunciation: "Yeda" },
    french: { text: "Nourriture", pronunciation: "/nuʁityʁ/" },
    portuguese: { text: "Comida", pronunciation: "/koˈmidɐ/" },
    japanese: { text: "食べ物", pronunciation: "Tabemono" }
  }
};

const culturalContexts: Record<string, Partial<Record<Language, string>>> = {
  hello: {
    english: "A universal greeting used in most situations.",
    swahili: "Used throughout East Africa. Can be replied with 'Jambo' as well.",
    mandarin: "Formal greeting. The tone is important - 3rd tone then 3rd tone.",
    hindi: "Respectful greeting with spiritual meaning, often with palms together.",
    arabic: "Common in Middle East. Response is typically 'Ahlan wa sahlan'.",
    spanish: "Casual greeting used throughout the day in Spanish-speaking countries.",
    russian: "Informal greeting among friends and family.",
    french: "Standard greeting, literally means 'good day'.",
    portuguese: "Universal greeting in Portuguese-speaking countries.",
    japanese: "Formal afternoon greeting. Use 'Ohayou' in the morning."
  },
  "thank you": {
    english: "Standard expression of gratitude in all contexts.",
    swahili: "Simple and widely used across East Africa.",
    mandarin: "Can be repeated twice for emphasis. Used in both formal and informal settings.",
    hindi: "Formal and respectful way to express gratitude.",
    arabic: "Universal expression of thanks across Arab-speaking countries.",
    spanish: "Used in all Spanish-speaking countries with slight variations.",
    russian: "Most common way to say thank you in Russia.",
    french: "Standard thank you, used in both formal and informal contexts.",
    portuguese: "Men say 'Obrigado', women say 'Obrigada'.",
    japanese: "Casual form. Use 'Arigatou gozaimasu' for formal situations."
  }
};

export function translateFromDictionary(word: string, from: Language, to: Language): TranslationResult | null {
  const normalizedWord = word.toLowerCase().trim();
  
  // Try exact match first
  let entry = dictionary[normalizedWord];
  let matchedWord = normalizedWord;
  
  // If no exact match, try fuzzy matching
  if (!entry) {
    const bestMatch = findBestMatch(normalizedWord);
    if (bestMatch) {
      entry = dictionary[bestMatch];
      matchedWord = bestMatch;
    }
  }
  
  if (!entry) {
    return null;
  }

  const fromTranslation = entry[from];
  const toTranslation = entry[to];
  const culturalContext = culturalContexts[matchedWord]?.[to];

  return {
    word: matchedWord,
    from: fromTranslation,
    to: toTranslation,
    culturalContext
  };
}

// Keep original function name for backwards compatibility
export const translate = translateFromDictionary;

export function getAvailableWords(): string[] {
  return Object.keys(dictionary);
}

export function searchWords(query: string): string[] {
  const normalizedQuery = query.toLowerCase().trim();
  return Object.keys(dictionary).filter(word => 
    word.includes(normalizedQuery) || 
    word.split(' ').some(part => part.startsWith(normalizedQuery))
  );
}

// Enhanced translation function with fuzzy matching
export function findBestMatch(input: string): string | null {
  const normalizedInput = input.toLowerCase().trim();
  
  // Exact match first
  if (dictionary[normalizedInput]) {
    return normalizedInput;
  }
  
  // Check for partial matches
  const words = Object.keys(dictionary);
  
  // Look for words that start with the input
  let match = words.find(word => word.startsWith(normalizedInput));
  if (match) return match;
  
  // Look for words that contain the input
  match = words.find(word => word.includes(normalizedInput));
  if (match) return match;
  
  // Look for single word in multi-word phrases
  const inputWords = normalizedInput.split(' ');
  for (const inputWord of inputWords) {
    if (inputWord.length > 2) { // Only check meaningful words
      match = words.find(word => 
        word.split(' ').some(part => part === inputWord)
      );
      if (match) return match;
    }
  }
  
  return null;
}
