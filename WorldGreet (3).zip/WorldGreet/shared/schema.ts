import { z } from "zod";

export const languages = [
  "english", "swahili", "mandarin", "hindi", "arabic", 
  "spanish", "russian", "french", "portuguese", "japanese"
] as const;

export type Language = typeof languages[number];

export const translationSchema = z.object({
  word: z.string().min(1),
  fromLanguage: z.enum(languages),
  toLanguage: z.enum(languages),
});

export const recentTranslationSchema = z.object({
  id: z.string(),
  word: z.string(),
  fromText: z.string(),
  toText: z.string(),
  fromLanguage: z.enum(languages),
  toLanguage: z.enum(languages),
  timestamp: z.number(),
});

export const favoriteTranslationSchema = z.object({
  id: z.string(),
  word: z.string(),
  fromText: z.string(),
  toText: z.string(),
  fromLanguage: z.enum(languages),
  toLanguage: z.enum(languages),
  timestamp: z.number(),
});

export type TranslationRequest = z.infer<typeof translationSchema>;
export type RecentTranslation = z.infer<typeof recentTranslationSchema>;
export type FavoriteTranslation = z.infer<typeof favoriteTranslationSchema>;

export interface TranslationData {
  text: string;
  pronunciation: string;
  audio?: string;
}

export interface TranslationResult {
  word: string;
  from: TranslationData;
  to: TranslationData;
  culturalContext?: string;
}
