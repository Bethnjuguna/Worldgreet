# Cultural Translation App

## Overview

This is a React-based cultural translation application that helps users translate words and phrases between different languages while providing cultural context. The app features a clean, modern interface built with React, TypeScript, and shadcn/ui components, with a Node.js/Express backend and PostgreSQL database support through Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ESM modules
- **API**: RESTful API structure (minimal implementation currently)
- **Middleware**: Express middleware for JSON parsing, request logging, and error handling

### Data Storage Solutions
- **Database**: PostgreSQL configured through Drizzle ORM
- **ORM**: Drizzle with Neon Database serverless driver
- **Local Storage**: Browser localStorage for recent translations and favorites
- **In-Memory Storage**: Temporary storage implementation for development

## Key Components

### Core Translation Features
- **Hybrid Translation System**: Built-in dictionary for common phrases with cultural context, external API for broader coverage
- **External API Integration**: LibreTranslate API fallback for words not in built-in dictionary
- **Language Support**: 10 languages including English, Swahili, Mandarin, Hindi, Arabic, Spanish, Russian, French, Portuguese, and Japanese
- **Translation Storage**: Recent translations and favorites stored in browser localStorage
- **Cultural Context**: Rich cultural context and pronunciation guides for built-in dictionary phrases

### UI Components
- **TranslatorCard**: Main translation interface with language selection and input
- **ResultsSection**: Displays translation results with audio and favorite buttons
- **RecentTranslations**: Shows user's recent translation history
- **FeatureCards**: Highlights key app features (pronunciation, cultural context, favorites)

### Storage Architecture
- **Schema Definitions**: Shared TypeScript schemas using Zod validation
- **Local Storage**: Utilities for managing recent translations and favorites
- **Database Schema**: Prepared for PostgreSQL with user management structure

## Data Flow

1. **User Input**: User enters text and selects source/target languages
2. **Translation Processing**: 
   - First attempts built-in dictionary lookup for rich content
   - Falls back to LibreTranslate API for broader coverage
   - Handles errors gracefully with helpful messaging
3. **Result Display**: Shows translated text with pronunciation guides (dictionary) or plain translation (API)
4. **Storage**: Saves successful translations to localStorage
5. **History Management**: Maintains recent translations list with automatic deduplication

## External Dependencies

### UI and Styling
- **Radix UI**: Headless UI primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library

### Data and State Management
- **TanStack Query**: Server state management and caching
- **Zod**: Runtime type validation and schema definition
- **Drizzle ORM**: Type-safe database ORM

### Development Tools
- **Vite**: Fast development server and build tool
- **ESBuild**: JavaScript bundler for production builds
- **TypeScript**: Static type checking

## Deployment Strategy

### Development
- **Dev Server**: Vite development server with HMR
- **Database**: Neon Database serverless PostgreSQL
- **Environment**: NODE_ENV=development with tsx for TypeScript execution

### Production
- **Build Process**: Vite builds client, ESBuild bundles server
- **Static Assets**: Client built to `dist/public` directory
- **Server**: Node.js server serving both API and static files
- **Database**: PostgreSQL via DATABASE_URL environment variable

### Replit Integration
- **Cartographer**: Development-only Replit integration for enhanced debugging
- **Runtime Error Overlay**: Development error handling
- **Banner Script**: Replit development environment indicator

## Architecture Decisions

### Hybrid Translation Architecture
**Problem**: Need both rich cultural content for common phrases and broad coverage for any text
**Solution**: Built-in dictionary with LibreTranslate API fallback
**Rationale**: Dictionary provides instant results with cultural context; API provides universal coverage without requiring paid services

### localStorage for User Data
**Problem**: Need to persist user preferences and history without authentication
**Solution**: Browser localStorage for recent translations and favorites
**Rationale**: Simple implementation, no server overhead, immediate data persistence

### Drizzle ORM
**Problem**: Need type-safe database interactions with PostgreSQL
**Solution**: Drizzle ORM with Neon Database serverless driver
**Rationale**: Type safety, excellent TypeScript integration, serverless-friendly

### shadcn/ui Component Library
**Problem**: Need consistent, accessible UI components quickly
**Solution**: shadcn/ui built on Radix UI primitives
**Rationale**: Copy-paste components, full customization control, excellent accessibility